# Python-Economy
Just do uhhhhhhhhhhhh... pip install git+https://github.com/ErrorThree/Python-Economy.git

Example:
  from economy import economy
